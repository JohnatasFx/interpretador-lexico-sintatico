/* main.c - um analisador l�xico e analisador sint�tico
 simples para express�es aritm�ticas simples */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

/* Declara��es globais */
/* Vari�veis */
int charClass;
char lexeme [100];
char nextChar;
int lexLen;
int token;
int nextToken;
FILE *in_fp, *fopen();

/* Declara��es de Fun��es */
void addChar();
void getChar();
void getString();
void getNonBlank();
int lex();
void getString();
void error();
void expr(int level);
void term(int level);
void factor(int level);
void operator(int level);

/* Classes de caracteres */
#define LETTER 0
#define DIGIT 1
#define QUOTE 2
#define STD_RESV 3
#define COUT_RESV 4
#define LIST_CHAR 5
#define UNKNOWN 99
/* C�digos de tokens */
#define INT_LIT 10
#define IDENT 11
#define ASSIGN_OP 20
#define ADD_OP 21
#define SUB_OP 22
#define MULT_OP 23
#define DIV_OP 24
#define LEFT_PAREN 25
#define RIGHT_PAREN 26
#define STRING_LIT 28
#define OUTPUT_OP 29
#define SEMI_COLON 30

/******************************************************/
/* fun��o principal */
int main() {

	char resposta[10];
	int i = 1;
	int *pi;
	pi = &i;
	int level = 0;

	while (i) {
		printf("Escolha uma opcao:\n");
		printf("1. Abrir arquivo de Exemplo.\n");
		printf("2. Escrever expressao.\n");
		printf("0. Sair\n");
		printf("Opcao: ");

		fgets(resposta, sizeof(resposta), stdin);

		// Remover o caractere de nova linha da resposta
		resposta[strcspn(resposta, "\n")] = '\0';

		// Verificar a op��o escolhida
		if (strcmp(resposta, "1") == 0) {
			printf("Opcao selecionada: Abrir arquivo de Exemplo.\n");
			if ((in_fp = fopen("exemplo.txt", "r")) == NULL)
				printf("ERROR - cannot open exemplo.txt \n");
			else {
				getChar();
				do {
					lex();
					expr(level);
				} while (nextToken != EOF);
			}
		} else if (strcmp(resposta, "2") == 0) {
			printf("Opcao selecionada: Escrever expressao.\n");
			char input[100];
			printf("Digite uma expressao: ");
			scanf("%s", input);
			getchar();
			in_fp = fopen("temp.txt", "w+");
			fprintf(in_fp, "%s", input);
			fclose(in_fp);

			/* Abrir o arquivo e dados de entrada e processar seu
			conteudo */
			if ((in_fp = fopen("temp.txt", "r")) == NULL)
				printf("ERROR - cannot open temp.txt \n");
			else {
				getChar();
				do {
					lex();
					expr(level);
				} while (nextToken != EOF);
			}
		} else if (strcmp(resposta, "0") == 0) {
			printf("Saindo...\n");
			*pi = 0;
		} else {
			printf("Opcao invalida! Tente novamente.\n");
		}
	}

	return 0;
}
/******************************************************/
/* lookup - uma fun��o para processar operadores e par�nteses
 e retornar o token */
int lookup(char ch) {
	switch (ch) {
		case '(':
			addChar();
			nextToken = LEFT_PAREN;
			break;
		case ')':

			addChar();
			nextToken = RIGHT_PAREN;
			break;
		case '+':
			addChar();
			nextToken = ADD_OP;
			break;
		case '-':
			addChar();
			nextToken = SUB_OP;
			break;
		case '*':
			addChar();
			nextToken = MULT_OP;
			break;
		case '/':
			addChar();
			nextToken = DIV_OP;
			break;
		case ';':
			addChar();
			nextToken = SEMI_COLON;
			break;
		default:
			addChar();
			nextToken = EOF;
			break;
	}

	return nextToken;
}
/*****************************************************/
/* addChar - uma fun��o para adicionar nextChar ao
vetor lexeme */
void addChar() {
	if (lexLen <= 98) {
		lexeme[lexLen++] = nextChar;
		lexeme[lexLen] = 0;
	} else
		printf("Error - lexeme is too long \n");
}
/*******************************************************/
/* getChar - uma fun��o para obter o pr�ximo caractere da entrada e determinar sua classe de caracteres */
void getChar() {
	if ((nextChar = getc(in_fp)) != EOF) {
		if (isalpha(nextChar))
			charClass = LETTER;

		else if (isdigit(nextChar))
			charClass = DIGIT;
		else if (nextChar == '"')
			charClass = QUOTE;
		else if (nextChar == ':') {
			charClass = STD_RESV;
		} else if (nextChar == '<') {
			charClass = COUT_RESV;
		} else
			charClass = UNKNOWN;
	} else
		charClass = EOF;
}

/*******************************************************************/
/* getString - uma fun��o para obter o pr�ximo char da entrada
para aceitar qualquer caractere string, com exce��o de " e quebra de linha */
void getString () {
	if ((nextChar = getc(in_fp)) != EOF) {
		if (nextChar == '"') {
			charClass = QUOTE;
		} else if (nextChar == '\n') {
			error();
		} else
			charClass = LIST_CHAR;
	} else {
		charClass = EOF;
	}
}

/*******************************************************/
/* getNonBlank - uma fun��o para chamar getChar at� que ela
retorne um caractere diferente de espa�o em
branco */
void getNonBlank() {
	while (isspace(nextChar))
		getChar();
}
/********************************************************/
/* lex - um analisador l�xico simples para express�es
aritm�ticas */
int lex() {
	lexLen = 0;
	getNonBlank();
	switch (charClass) {
			/* Reconhecer identificadores */
		case LETTER:
			addChar();
			getChar();
			while (charClass == LETTER || charClass == DIGIT) {
				addChar();
				getChar();
			}
			if (strcmp(lexeme, "std::cout") == 0) { // Verificar se � "std::cout"
				nextToken = COUT_RESV; // Atribuir token correspondente
			} else {
				nextToken = IDENT;
			}
			break;
			/* Reconhecer literais inteiros */
		case DIGIT:
			addChar();
			getChar();
			while (charClass == DIGIT) {
				addChar();
				getChar();
			}
			nextToken = INT_LIT;
			break;
			/* Caracteres de express�es*/
		case QUOTE:
			addChar();
			getString();
			while(charClass == LIST_CHAR) {
				addChar();
				getString();
			}
			if(charClass == QUOTE) {
				addChar();
				getChar();
				nextToken = STRING_LIT;
			} else {
				error();
			}
			break;
		case UNKNOWN:
			lookup(nextChar);
			getChar();
			break;
			/* Fim do arquivo */
		case EOF:
			nextToken = EOF;
			lexeme[0] = 'E';
			lexeme[1] = 'O';
			lexeme[2] = 'F';
			lexeme[3] = 0;
			break;
	} /* Fim do switch */
	return nextToken;
} /* Fim da fun��o lex */

//Imprime o nome do Token ao inves de seu codigo
void imprimirNomeToken(int token) {
	switch (token) {
		case INT_LIT:
			printf("INT_LIT");
			break;
		case IDENT:
			printf("IDENT");
			break;
		case ASSIGN_OP:
			printf("ASSIGN_OP");
			break;
		case ADD_OP:
			printf("ADD_OP");
			break;
		case SUB_OP:
			printf("SUB_OP");
			break;
		case MULT_OP:
			printf("MULT_OP");
			break;
		case DIV_OP:
			printf("DIV_OP");
			break;
		case LEFT_PAREN:
			printf("LEFT_PAREN");
			break;
		case RIGHT_PAREN:
			printf("RIGHT_PAREN");
			break;
/* tokens das palavras reservadas de C++*/
		case STD_RESV:
			printf("STD_RESV");
			break;
		case COUT_RESV:
			printf("COUT_RESV");
			break;
		case STRING_LIT:
			printf("STRING_LIT");
			break;
		case OUTPUT_OP:
			printf("OUTPUT_OP");
			break;
		default:
			printf("Token desconhecido");
			break;
	}
}
/*mensagem de Erro*/
void error() {
	printf("Error - ocorreu um erro na analise sintatica\n");
	exit(1);
}

/* expr
 Analisa sintaticamente cadeias na linguagem gerada pela
regra:
 <expr> -> <term> {(+ | -) <term>}
 */
// Funcao <statement> -> <command> | <string> | <expr>
// Funcao <statement> -> <command> | <string> | <expr>
void expr(int level) {
	printf("%*sEnter <expr>\n", level, "");
	level = level + 5;
	term(level);

	while (nextToken == ADD_OP || nextToken == SUB_OP) {
		operator(level);
		lex();
		term(level);
	}


	printf("%*sExit <expr>\n", level - 5, "");
}

/* term
 Analisa sintaticamente cadeias na linguagem gerada pela
regra:
 <term> -> <factor> {(* | /) <factor>)
 */
void term(int level) {
	printf("%*sEnter <term>\n", level, "");
	level = level + 5;

	factor(level);

	while (nextToken == MULT_OP || nextToken == DIV_OP) {
		operator(level);
		lex();
		factor(level);
	}

	printf("%*sExit <term>\n", level - 5, "");

}

/* factor
 Analisa sintaticamente cadeias na linguagem gerada pela
regra:
 <factor> -> id | int_constant | (<expr)
 */
/* factor
 Analisa sintaticamente cadeias na linguagem gerada pela
regra:
 <factor> -> id | int_constant | (<expr)
 */
void factor(int level) {
	printf("%*sEnter <factor>\n", level, "");

	/* Determina qual RHS */
	if (nextToken == IDENT || nextToken == INT_LIT) {
		printf("%*s", level, "");
		imprimirNomeToken(nextToken);
		printf(" --> %s\n", lexeme);
		/* Obt�m o proximo token */
		lex();
	}

	/* Se a RHS � (<expr>), chame lex para passar o par�ntese
	esquerdo, chame expr e verifique pelo par�ntese
	direito */
	else {
		if (nextToken == LEFT_PAREN) {
			printf("%*s", level, "");
			imprimirNomeToken(nextToken);
			printf(" --> %s\n", lexeme);
			lex();
			expr(level);
			if (nextToken == RIGHT_PAREN) {
				printf("%*s", level, "");
				imprimirNomeToken(nextToken);
				printf(" --> %s\n", lexeme);
				lex();
			} else
				error();
		}
		/* N�o era um identificador, um literal inteiro ou um
		par�ntese esquerdo */
		else
			error();
	}

	printf("%*sExit <factor>\n", level, "");
}
/*fun��o para imprimir os operadores*/
void operator (int level) {
	printf("%*s", level, "");
	imprimirNomeToken(nextToken);
	printf(" --> %s\n", lexeme);
}
